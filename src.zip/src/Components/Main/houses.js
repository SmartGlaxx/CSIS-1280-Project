import { useEffect, useState } from "react";
import Image1 from "../../assets/buildings/one.png";
import Image2 from "../../assets/buildings/two.png";
import Image3 from "../../assets/buildings/three.png";
import Image4 from "../../assets/buildings/four.png";
import Image5 from "../../assets/buildings/five.png";
import Image6 from "../../assets/buildings/six.png";
import Image7 from "../../assets/buildings/seven.png";
import Image8 from "../../assets/buildings/eight.png";
import Image9 from "../../assets/buildings/nine.png";
import Image10 from "../../assets/buildings/ten.png";
import Image11 from "../../assets/buildings/eleven.png";
import { UseAppContext } from "../../context"

export const House1=()=>{

    const {token1XPos, token1YPos, token2XPos, token2YPos,
        token3XPos, token3YPos, token4XPos, token4YPos,
        aResidents, bResidents, cResidents, dResidents,
        setAResidents, setBResidents, setCResidents, setDResidents
     } = UseAppContext()


    const occupants = 20;
    let newAResidents = 0
    let newBResidents = 0
    let newCResidents = 0
    let newDResidents = 0
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;
    const [posX, setposX] = useState(0);
    const [posY, setposY] = useState(0);
    const distXFromA = Math.abs(token1XPos - posX);
    const distYFromA = Math.abs(token1YPos - posY);
    const totalFromA = Math.sqrt(Math.pow(distXFromA, 2) + Math.pow(distYFromA, 2))
    const distXFromB = Math.abs(token2XPos - posX);
    const distYFromB = Math.abs(token2YPos - posY);
    const totalFromB = Math.sqrt(Math.pow(distXFromB, 2) + Math.pow(distYFromB, 2))
    const distXFromC = Math.abs(token3XPos - posX);
    const distYFromC = Math.abs(token3YPos - posY);
    const totalFromC = Math.sqrt(Math.pow(distXFromC, 2) + Math.pow(distYFromC, 2))
    const distXFromD = Math.abs(token4XPos - posX);
    const distYFromD = Math.abs(token4YPos - posY);
    const totalFromD = Math.sqrt(Math.pow(distXFromD, 2) + Math.pow(distYFromD, 2))

    const totalValue = Math.min(totalFromA, totalFromB, totalFromC, totalFromD)
    console.log("Values:"+ totalFromA, totalFromB, totalFromC, totalFromD)
        // switch(totalValue){
        //     case totalFromA:
        //         newAResidents = occupants
        //         console.log("A")
        //         break
        //     case totalFromB:
        //         console.log("B")
        //         newBResidents = occupants
        //         break
        //     case totalFromC:
        //         console.log("C")
        //         newCResidents = occupants
        //         break
        //     case totalFromD:
        //         console.log("D")
        //         newDResidents = occupants
        //         break
        // }
    useEffect(()=>{
        switch(totalValue){
            case totalFromA:
                newAResidents = occupants
                console.log("A")
                setAResidents(newAResidents)
                
                break
            case totalFromB:
                console.log("B")
                newBResidents = occupants
                setBResidents(newBResidents)
                break
            case totalFromC:
                console.log("C")
                newCResidents = occupants
                setCResidents(newCResidents)   
                break
            case totalFromD:
                console.log("D")
                newDResidents = occupants
                setDResidents(newDResidents)
                break
        }
        
    },[totalValue])
    // useEffect(()=>{
    //     setAResidents(0)
    //     setBResidents(newBResidents)
    //     setCResidents(0)
    //     setDResidents(0)
    // },[newBResidents])
    // useEffect(()=>{
    //     setAResidents(0)
    //     setBResidents(0)
    //     setCResidents(newCResidents)
    //     setDResidents(0)
    // },[newCResidents])
    // useEffect(()=>{
    //     setAResidents(0)
    //     setBResidents(0)
    //     setCResidents(0)
    //     setDResidents(newDResidents)
    // },[newDResidents])
    const minValue = Math.min()

    const setPostion = ()=>{
        const posXValue = Math.random() * windowWidth;
        const posYValue = Math.random() * windowHeight;
        setposX(posXValue);
        setposY(posYValue);
    }
    useEffect(()=>{
        setPostion();
    },[])
    return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
        <img src={Image1} alt="house1" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
        <div>{aResidents}</div>
        <div>{bResidents}</div>
        <div>{cResidents}</div>
        <div>{dResidents}</div>
    </div>
// console.log("New:" + aResidents)
}
// export const House2=()=>{
//     const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image2} alt="house2" style={{top: `${posY}px`, left: `${posX}px`}} className="house" />
//     </div>
// }
// export const House3=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image3} alt="house3" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House4=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image4} alt="house4" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House5=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image5} alt="house5" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House6=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image6} alt="house6" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House7=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image7} alt="house7" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House8=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image8} alt="house8" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House9=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image9} alt="house9" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House10=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image10} alt="house10" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }



// export const House11=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image1} alt="house11" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }

// export const House12=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image2} alt="house12" style={{top: `${posY}px`, left: `${posX}px`}} className="house" />
//     </div>
// }
// export const House13=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image3} alt="house13" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House14=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image4} alt="house14" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House15=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image5} alt="house15" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House16=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image6} alt="house16" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House17=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image7} alt="house17" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House18=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image8} alt="house18" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House19=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image9} alt="house19" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House20=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image10} alt="house20" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House21=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image8} alt="house21" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }


// export const House22=()=>{
//     const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image2} alt="house22" style={{top: `${posY}px`, left: `${posX}px`}} className="house" />
//     </div>
// }
// export const House23=()=>{
//      const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])
//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image3} alt="house23" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House24=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image4} alt="house24" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }
// export const House25=()=>{
//       const windowWidth = window.innerWidth;
//     const windowHeight = window.innerHeight;
//     const [posX, setposX] = useState(0);
//     const [posY, setposY] = useState(0);
//     const setPostion = ()=>{
//         const posXValue = Math.random() * windowWidth;
//         const posYValue = Math.random() * windowHeight;
//         setposX(posXValue);
//         setposY(posYValue);
//     }
//     useEffect(()=>{
//         setPostion();
//     },[])

//     return <div style={{zIndex:"0", background:"none", width:"0px", height:"0px"}}>
//         <img src={Image5} alt="house25" style={{top: `${posY}px`, left: `${posX}px`}} className="house"  />
//     </div>
// }