import Main from './Components/Main/index';
import './App.css';


function App() {
  return (
    <section className="main">
      <Main />
    </section>
  );
}

export default App;
